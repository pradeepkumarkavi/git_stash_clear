# git-cleanup
Small script used to clear all stashes, uncommited work and local branches not on the remote repository and reset onto the default branch of the repository.

Simply run the script from a repository of your choice.
